KlAkOAPI Library
------------------

KlAkOAPI is a wrapper library for interacting Kaspersky Security Center (aka KSC) server with KSC Open API
For detailed description of KSC Open API protocol please refer to KLOAPI documentation pages